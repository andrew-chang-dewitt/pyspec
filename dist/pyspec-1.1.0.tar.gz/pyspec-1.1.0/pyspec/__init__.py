from . import cli
from .lib.describe import describe
from .lib.comparisons import Comparisons

comparisons = Comparisons()
